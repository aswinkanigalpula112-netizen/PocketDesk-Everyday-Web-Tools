# Status Saver

Native Kotlin and Jetpack Compose app for saving WhatsApp status photos and videos locally.

## Storage behavior

- Automatic discovery queries Android MediaStore and displays only items whose indexed location identifies WhatsApp and Status. Hidden `.Statuses` content is commonly excluded from MediaStore, so an empty automatic scan does not mean there are no statuses.
- The folder picker remembers a user-granted folder and scans only a folder named `.Statuses`, including one nested in a selected parent. Android's system picker may hide or deny access to that location on some devices.
- Import files opens Android's document picker for user-selected images and videos when automatic discovery or folder access is unavailable.
- Photos are saved to `Pictures/StatusSaver`; videos are saved to `Movies/StatusSaver`. Exact byte-identical copies in those folders are skipped using SHA-256.
- `Delete all Status Saver downloads` removes only copies the app saved in `Pictures/StatusSaver` and `Movies/StatusSaver`. WhatsApp's `.Statuses` cache is read-only to this app and remains available for later viewing and manual saving.
- Video thumbnails use decoded video frames with Android's thumbnail API as fallback. Videos play inside Status Saver through Media3's Compose `PlayerSurface` using a `TextureView` and in-app playback controls; the app does not redirect to an external media player.
- The home screen separates `All statuses` from `Import & tools`. The app never downloads statuses automatically; use an item's download button or select items and tap `Save all`.
- Automatic discovery filters MediaStore to common WhatsApp and WhatsApp Business `.Statuses` path prefixes and limits SAF folder search to common WhatsApp media paths to reduce startup scans.
- The app has no server, account, chat, message, contacts, root, accessibility-service, or WhatsApp database access.

## Build

Open this directory in Android Studio and build the `app` release variant, or run `gradlew.bat assembleRelease` after installing JDK 17 and Android SDK Platform 35 / Build Tools 35.0.0. The APK is written to `app/build/outputs/apk/release/app-release.apk`.

## Install and try on a phone

1. Copy `app-debug.apk` to the phone and open it. If asked, allow installation from that file app.
2. Launch Status Saver and allow photo/video access for the automatic MediaStore scan.
3. Open WhatsApp and view a status. Return to Status Saver and tap Refresh.
4. If the scan is empty, tap Choose folder and try selecting WhatsApp > Media > .Statuses. If Android does not expose it, tap Import files and select the status media from the document picker.
5. Open a photo or video to preview it. Use the download icon to save one item, or select items and tap Save all.
6. Check the phone's gallery or Files app under Pictures/StatusSaver and Movies/StatusSaver. Save an item a second time to confirm the duplicate is skipped.

## Compatibility validation status

No physical Android device or WhatsApp installation is attached to this build environment. Therefore automatic discovery, device folder-picker visibility, playback, MediaStore saving, and duplicate handling have not been validated against a specific Android or WhatsApp version. Test those steps on the target phone before relying on automatic discovery. Android scoped storage and WhatsApp sandbox restrictions vary with Android release, manufacturer picker, WhatsApp version, and storage layout.
