package com.statussaver.app

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.media.MediaMetadataRetriever
import android.provider.MediaStore
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.compose.PlayerSurface
import androidx.media3.ui.compose.SURFACE_TYPE_TEXTURE_VIEW
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.security.MessageDigest

private enum class MediaKind { PHOTO, VIDEO }
private data class StatusMedia(val uri: Uri, val name: String, val kind: MediaKind, val size: Long, val source: String, val modifiedAt: Long = 0L) {
    val fingerprint: String get() = "$uri|$size|$modifiedAt"
}
private enum class MediaTab { ALL, PHOTOS, VIDEOS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StatusSaverApp() }
    }
}

@Composable
private fun StatusSaverApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("status_saver", 0) }
    var media by remember { mutableStateOf<List<StatusMedia>>(emptyList()) }
    var savedCopies by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<Uri>>(emptySet()) }
    var tab by remember { mutableStateOf(MediaTab.ALL) }
    var page by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf("Status Saver only shows image and video files you can access.") }
    var justAdded by remember { mutableStateOf<Set<String>>(emptySet()) }
    var hasScanned by remember { mutableStateOf(false) }
    var confirmDeleteSaved by remember { mutableStateOf(false) }
    var storageActionsExpanded by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf<StatusMedia?>(null) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }

    fun refreshSavedCopies() {
        scope.launch {
            savedCopies = withContext(Dispatchers.IO) { queryStatusSaverCopies(context) }
        }
    }

    fun refresh() {
        loading = true
        message = null
        scope.launch {
            try {
                val found = withContext(Dispatchers.IO) { discoverMedia(context, prefs) }
                savedCopies = withContext(Dispatchers.IO) { queryStatusSaverCopies(context) }
                media = found.distinctBy { it.uri }
                val known = prefs.getStringSet("known_status_entries", null)
                justAdded = if (known == null) emptySet() else media.filter { it.fingerprint !in known }.map { it.fingerprint }.toSet()
                prefs.edit().putStringSet("known_status_entries", media.map { it.fingerprint }.toSet()).apply()
                selected = emptySet()
                hasScanned = true
                info = if (found.isEmpty()) "No accessible statuses found. Choose the WhatsApp .Statuses folder or import status files." else "${found.size} accessible status ${if (found.size == 1) "item" else "items"}${if (justAdded.isNotEmpty()) " · ${justAdded.size} new" else ""}"
            } catch (e: SecurityException) {
                message = "Storage permission was denied. Allow photo and video access, or use folder selection/import."
            } catch (e: Exception) {
                message = "Could not read status media. You can try choosing the folder or importing files."
            } finally { loading = false }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) refresh() else { loading = false; message = "Media access was denied. You can still choose a folder or import files." }
    }
    fun requestAndRefresh() {
        val needed = if (Build.VERSION.SDK_INT >= 34) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) else if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        val missing = needed.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) refresh() else permissionLauncher.launch(missing.toTypedArray())
    }

    fun deleteAllSavedCopies(items: List<Uri>) {
        confirmDeleteSaved = false
        loading = true
        scope.launch(Dispatchers.IO) {
            var removed = 0
            var failed = 0
            items.forEach { uri ->
                try {
                    if (context.contentResolver.delete(uri, null, null) > 0) removed++ else failed++
                } catch (_: Exception) { failed++ }
            }
            withContext(Dispatchers.Main) {
                notice = if (failed == 0) "Deleted $removed saved ${if (removed == 1) "file" else "files"}" else "Deleted $removed files · $failed could not be deleted"
                refresh()
            }
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && hasScanned && !loading) refresh()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("tree", uri.toString()).apply()
            info = "Folder connected. Scanning it for images and videos…"
            refresh()
        }
    }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val imported = uris.mapNotNull { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val type = context.contentResolver.getType(uri).orEmpty()
                val kind = if (type.startsWith("image/")) MediaKind.PHOTO else if (type.startsWith("video/")) MediaKind.VIDEO else null
                kind?.let { StatusMedia(uri, displayName(context, uri), it, querySize(context, uri), "Imported") }
            }
            media = (media + imported).distinctBy { it.uri }
            info = "${imported.size} selected status ${if (imported.size == 1) "file" else "files"} added"
            message = if (imported.isEmpty()) "Choose image or video status files." else null
        }
    }

    LaunchedEffect(Unit) {
        prefs.getString("tree", null)?.let { savedTree ->
            try { context.contentResolver.releasePersistableUriPermission(Uri.parse(savedTree), Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
        }
        requestAndRefresh()
    }
    val visibleMedia = media.filter { tab == MediaTab.ALL || (tab == MediaTab.PHOTOS && it.kind == MediaKind.PHOTO) || (tab == MediaTab.VIDEOS && it.kind == MediaKind.VIDEO) }
    val orderedMedia = visibleMedia.sortedByDescending { it.fingerprint in justAdded }
    val snackbarState = remember { SnackbarHostState() }
    LaunchedEffect(notice) { notice?.let { snackbarState.showSnackbar(it); notice = null } }
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFF9BE2BC), secondary = Color(0xFF73C99D), background = Color(0xFF101713), surface = Color(0xFF19221D)) else lightColorScheme(primary = Color(0xFF176B4A), secondary = Color(0xFF26845D), background = Color(0xFFF5F8F5), surface = Color.White)) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background, snackbarHost = { SnackbarHost(snackbarState) }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
              Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 22.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primary), Alignment.Center) { Icon(Icons.Default.OfflinePin, null, tint = MaterialTheme.colorScheme.background, modifier = Modifier.size(27.dp)) }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text("Status Saver", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        Text("Your status media, saved locally", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { dark = !dark; prefs.edit().putBoolean("dark", dark).apply() }) { Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") }
                    IconButton(onClick = { requestAndRefresh() }, enabled = !loading) { Icon(Icons.Default.Refresh, "Refresh") }
                }

                TabRow(selectedTabIndex = page, containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.primary) {
                    Tab(page == 0, { page = 0; selected = emptySet() }, text = { Text("All statuses · ${media.size}") }, icon = { Icon(Icons.Default.Folder, null) })
                    Tab(page == 1, { page = 1; selected = emptySet() }, text = { Text("Import & tools") }, icon = { Icon(Icons.Default.Tune, null) })
                }

                if (page == 1) Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text("  Private by design", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { treePicker.launch(prefs.getString("tree", null)?.let(Uri::parse)) }) { Text("Choose folder") }
                        }
                        Text("View statuses in WhatsApp, then return and refresh. Android may hide .Statuses; WhatsApp contact names aren’t included in its file list.", fontSize = 12.sp, lineHeight = 17.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { importPicker.launch(arrayOf("image/*", "video/*")) }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)) { Icon(Icons.Default.FileOpen, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Import files") }
                            OutlinedButton(onClick = { requestAndRefresh() }, enabled = !loading, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)) { Icon(Icons.Default.Refresh, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Refresh") }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { storageActionsExpanded = !storageActionsExpanded }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) {
                                Text(if (storageActionsExpanded) "Less" else "Storage tools")
                                Icon(if (storageActionsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, Modifier.size(18.dp))
                            }
                        }
                        if (storageActionsExpanded) {
                            OutlinedButton(onClick = { if (savedCopies.isNotEmpty()) confirmDeleteSaved = true }, enabled = !loading && savedCopies.isNotEmpty(), modifier = Modifier.fillMaxWidth().padding(top = 8.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) {
                                Icon(Icons.Default.DeleteOutline, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text(if (savedCopies.isNotEmpty()) "Delete all Status Saver downloads · ${savedCopies.size}" else "No saved downloads to delete")
                            }
                            Text("Statuses stay in WhatsApp and remain available to view. Status Saver copies a file only when you tap Download or Save all. Delete all downloads removes only Status Saver copies from Pictures/StatusSaver and Movies/StatusSaver.", Modifier.padding(top = 5.dp), fontSize = 11.sp, lineHeight = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                if (page == 0) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(info, Modifier.weight(1f), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (media.isNotEmpty()) TextButton(onClick = { selected = if (selected.size == visibleMedia.size) emptySet() else visibleMedia.map { it.uri }.toSet() }) { Text(if (selected.size == visibleMedia.size && visibleMedia.isNotEmpty()) "Clear" else "Select all") }
                }
                TabRow(selectedTabIndex = when (tab) { MediaTab.ALL -> 0; MediaTab.PHOTOS -> 1; MediaTab.VIDEOS -> 2 }, containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.primary) {
                    Tab(tab == MediaTab.ALL, { tab = MediaTab.ALL; selected = emptySet() }, text = { Text("All  ·  ${media.size}") })
                    Tab(tab == MediaTab.PHOTOS, { tab = MediaTab.PHOTOS; selected = emptySet() }, text = { Text("Photos  ·  ${media.count { it.kind == MediaKind.PHOTO }}") }, icon = { Icon(Icons.Default.Image, null) })
                    Tab(tab == MediaTab.VIDEOS, { tab = MediaTab.VIDEOS; selected = emptySet() }, text = { Text("Videos  ·  ${media.count { it.kind == MediaKind.VIDEO }}") }, icon = { Icon(Icons.Default.Videocam, null) })
                }

                Box(Modifier.weight(1f).fillMaxWidth()) { when {
                    loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(); Spacer(Modifier.height(12.dp)); Text("Looking for accessible statuses…") } }
                    message != null -> StatePanel(Icons.Default.FolderOff, "Access needs a hand", message!!, "Choose folder", { treePicker.launch(null) }, "Import files", { importPicker.launch(arrayOf("image/*", "video/*")) })
                    visibleMedia.isEmpty() -> StatePanel(if (tab == MediaTab.VIDEOS) Icons.Default.VideoLibrary else Icons.Default.PhotoLibrary, if (media.isEmpty()) "No statuses found yet" else if (tab == MediaTab.ALL) "No status media here" else "No ${tab.name.lowercase()} here", if (media.isEmpty()) "Viewed WhatsApp statuses may be hidden from Android’s media library. Connect the .Statuses folder or import files to get started." else "Try another tab or refresh after viewing more WhatsApp statuses.", "Choose folder", { treePicker.launch(null) }, "Import files", { importPicker.launch(arrayOf("image/*", "video/*")) })
                    else -> Column {
                        if (orderedMedia.any { it.fingerprint in justAdded }) Text("NEW SINCE YOUR LAST SCAN", Modifier.fillMaxWidth().padding(start = 18.dp, top = 10.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        LazyVerticalGrid(columns = GridCells.Adaptive(150.dp), modifier = Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(orderedMedia, key = { it.uri.toString() }) { item ->
                            MediaCard(item, item.uri in selected, item.fingerprint in justAdded, { preview = item }, { selected = if (item.uri in selected) selected - item.uri else selected + item.uri }, { scope.launch(Dispatchers.IO) { saveMedia(context, listOf(item)) { saved, skipped, error -> scope.launch(Dispatchers.Main) { notice = saveMessage(saved, skipped, error); if (saved > 0) refreshSavedCopies() } } } })
                        }
                    }
                    }
                } }
                }
              }
            if (page == 0 && selected.isNotEmpty()) Button(onClick = { val chosen = media.filter { it.uri in selected }; scope.launch(Dispatchers.IO) { saveMedia(context, chosen) { saved, skipped, error -> scope.launch(Dispatchers.Main) { notice = saveMessage(saved, skipped, error); selected = emptySet(); if (saved > 0) refreshSavedCopies() } } } }, modifier = Modifier.align(Alignment.BottomCenter).padding(18.dp).fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("Save all  ·  ${selected.size}", fontWeight = FontWeight.SemiBold) }
            preview?.let { item -> PreviewDialog(item) { preview = null } }
            if (confirmDeleteSaved) AlertDialog(
                onDismissRequest = { confirmDeleteSaved = false },
                title = { Text("Delete all Status Saver downloads?") },
                text = { Text("This permanently deletes ${savedCopies.size} copies saved by Status Saver in Pictures/StatusSaver and Movies/StatusSaver. Your statuses remain in WhatsApp and stay available in All statuses.") },
                confirmButton = { TextButton(onClick = { deleteAllSavedCopies(savedCopies) }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Delete downloads") } },
                dismissButton = { TextButton(onClick = { confirmDeleteSaved = false }) { Text("Cancel") } }
            )
        }
    }
}

}

@Composable
private fun StatePanel(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, body: String, firstLabel: String, first: () -> Unit, secondLabel: String, second: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(76.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface), Alignment.Center) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp)) }
        Spacer(Modifier.height(18.dp)); Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp))
        Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, lineHeight = 21.sp)
        Spacer(Modifier.height(20.dp)); Button(onClick = first) { Text(firstLabel) }; TextButton(onClick = second) { Text(secondLabel) }
    }
}

@Composable
private fun MediaCard(item: StatusMedia, selected: Boolean, newlyAdded: Boolean, onOpen: () -> Unit, onSelect: () -> Unit, onSave: () -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.clickable { onOpen() }) {
        Box(Modifier.fillMaxWidth().height(190.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
            if (item.kind == MediaKind.PHOTO) {
                AsyncImage(model = item.uri, contentDescription = item.name, modifier = Modifier.fillMaxSize())
            } else {
                VideoThumbnail(item.uri, Modifier.fillMaxSize())
                Box(Modifier.align(Alignment.Center).size(46.dp).clip(CircleShape).background(Color.Black.copy(alpha = .65f)), Alignment.Center) { Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
            }
            if (newlyAdded) Surface(Modifier.align(Alignment.TopStart).padding(8.dp), shape = RoundedCornerShape(99.dp), color = MaterialTheme.colorScheme.primary) { Text("NEW", Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = MaterialTheme.colorScheme.onPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            Surface(Modifier.align(Alignment.TopEnd).padding(8.dp).clickable { onSelect() }, shape = CircleShape, color = if (selected) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = .45f)) { Icon(if (selected) Icons.Default.Check else Icons.Default.Circle, "Select", tint = if (selected) MaterialTheme.colorScheme.onPrimary else Color.White, modifier = Modifier.padding(7.dp).size(18.dp)) }
        }
        Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 6.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, fontWeight = FontWeight.Medium); Text(if (item.size > 0) "${item.size / 1024} KB" else item.source, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            IconButton(onClick = onSave) { Icon(Icons.Default.Download, "Save") }
        }
    }
}

@Composable
private fun VideoThumbnail(uri: Uri, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = uri) {
        value = withContext(Dispatchers.IO) {
            val frame = try {
                MediaMetadataRetriever().run {
                    try {
                        setDataSource(context, uri)
                        getScaledFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 480, 640)
                            ?: getScaledFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 480, 640)
                    } finally { release() }
                }
            } catch (_: Exception) { null }
            frame ?: try { context.contentResolver.loadThumbnail(uri, Size(480, 640), CancellationSignal()) } catch (_: Exception) { null }
        }
    }
    if (bitmap != null) {
        Image(bitmap!!.asImageBitmap(), contentDescription = "Video thumbnail", modifier = modifier, contentScale = ContentScale.Fit)
    } else {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Videocam, contentDescription = "Video", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .65f), modifier = Modifier.size(36.dp))
        }
    }
}

@Composable
private fun PreviewDialog(item: StatusMedia, close: () -> Unit) {
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(item.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = close) { Icon(Icons.Default.Close, "Close preview") }
                }
                if (item.kind == MediaKind.PHOTO) {
                    AsyncImage(model = item.uri, contentDescription = item.name, modifier = Modifier.fillMaxWidth().heightIn(max = 560.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit)
                } else {
                    InAppVideoPlayer(item.uri)
                }
            }
        }
    }
}

@Composable
private fun InAppVideoPlayer(uri: Uri) {
    val context = LocalContext.current
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val maxPlayerHeight = (screenHeight * 0.56f).coerceAtMost(480.dp)
    var ready by remember(uri) { mutableStateOf(false) }
    var playing by remember(uri) { mutableStateOf(false) }
    var failed by remember(uri) { mutableStateOf(false) }
    var duration by remember(uri) { mutableLongStateOf(0L) }
    var position by remember(uri) { mutableLongStateOf(0L) }
    var aspectRatio by remember(uri) { mutableFloatStateOf(9f / 16f) }
    val player = remember(uri) { ExoPlayer.Builder(context).build() }

    DisposableEffect(player, uri) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                ready = playbackState == Player.STATE_READY || playbackState == Player.STATE_ENDED
                if (ready) duration = player.duration.coerceAtLeast(0L)
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) { failed = true; playing = false }
            override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    val width = videoSize.width * videoSize.pixelWidthHeightRatio
                    val height = videoSize.height.toFloat()
                    aspectRatio = width / height
                }
            }
        }
        player.addListener(listener)
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.playWhenReady = true
        onDispose { player.removeListener(listener); player.release() }
    }
    LaunchedEffect(player) {
        while (true) {
            if (player.isPlaying) {
                position = player.currentPosition.coerceAtLeast(0L)
                duration = player.duration.coerceAtLeast(0L)
            }
            delay(300)
        }
    }

    val playerWidth = (maxPlayerHeight * aspectRatio).coerceAtMost((LocalConfiguration.current.screenWidthDp.dp - 64.dp))
    val playerHeight = playerWidth / aspectRatio
    PlayerSurface(player = player, modifier = Modifier.width(playerWidth).height(playerHeight).clip(RoundedCornerShape(12.dp)), surfaceType = SURFACE_TYPE_TEXTURE_VIEW)
    if (!ready && !failed) {
        LinearProgressIndicator(Modifier.width(playerWidth).padding(top = 8.dp))
    }
    if (failed) {
        Text("This video couldn’t be played inside Status Saver.", Modifier.padding(top = 10.dp), color = MaterialTheme.colorScheme.error)
    } else if (ready) {
        Row(Modifier.width(playerWidth).padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                if (player.playbackState == Player.STATE_ENDED) player.seekTo(0L)
                if (player.isPlaying) player.pause() else player.play()
            }) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause video" else "Play video")
            }
            Text(formatPlaybackTime(position), fontSize = 12.sp)
            Slider(
                value = position.toFloat().coerceIn(0f, duration.toFloat().coerceAtLeast(1f)),
                onValueChange = { position = it.toLong() },
                onValueChangeFinished = { player.seekTo(position) },
                valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                modifier = Modifier.weight(1f)
            )
            Text(formatPlaybackTime(duration), fontSize = 12.sp)
        }
    }
}

private fun formatPlaybackTime(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
    return "%d:%02d".format(totalSeconds / 60L, totalSeconds % 60L)
}

private fun discoverMedia(context: android.content.Context, prefs: android.content.SharedPreferences): List<StatusMedia> {
    val found = mutableListOf<StatusMedia>()
    val treeText = prefs.getString("tree", null)
    if (treeText != null) {
        try {
            val root = DocumentFile.fromTreeUri(context, Uri.parse(treeText))
            if (root != null) findStatusFolders(context, root, found, 0, intArrayOf(0))
        } catch (_: Exception) {}
    }
    val imageUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    listOf(imageUri to MediaKind.PHOTO, videoUri to MediaKind.VIDEO).forEach { (collection, kind) ->
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.MediaColumns.DATE_MODIFIED)
        val selection = "(${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?)"
        val selectionArgs = arrayOf(
            "WhatsApp/Media/.Statuses/%",
            "Android/media/com.whatsapp/WhatsApp/Media/.Statuses/%",
            "WhatsApp Business/Media/.Statuses/%",
            "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses/%"
        )
        try {
            context.contentResolver.query(collection, projection, selection, selectionArgs, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { cursor ->
                val id = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val name = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val size = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val path = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                val modified = cursor.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
                while (cursor.moveToNext()) {
                    val relative = if (path >= 0) cursor.getString(path).orEmpty() else ""
                    val whatsAppStatus = relative.contains("whatsapp", true) && (relative.contains("status", true) || relative.contains(".Statuses", true))
                    if (whatsAppStatus) found += StatusMedia(ContentUris.withAppendedId(collection, cursor.getLong(id)), cursor.getString(name) ?: "status", kind, cursor.getLong(size), "WhatsApp status", if (modified >= 0) cursor.getLong(modified) * 1000L else 0L)
                }
            }
        } catch (_: SecurityException) { }
    }
    return found
}

private fun queryStatusSaverCopies(context: android.content.Context): List<Uri> {
    val copies = mutableListOf<Uri>()
    listOf(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    ).forEach { collection ->
        val projection = arrayOf(MediaStore.MediaColumns._ID)
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} IN (?, ?) AND ${MediaStore.MediaColumns.OWNER_PACKAGE_NAME}=?"
        val args = arrayOf("Pictures/StatusSaver/", "Movies/StatusSaver/", context.packageName)
        try {
            context.contentResolver.query(collection, projection, selection, args, null)?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                while (cursor.moveToNext()) {
                    copies += ContentUris.withAppendedId(collection, cursor.getLong(idIndex))
                }
            }
        } catch (_: SecurityException) {
            // Files created by this app remain manageable through MediaStore; if a device
            // provider denies the query, keep the UI safe and report no deletable items.
        }
    }
    return copies
}

private fun findStatusFolders(context: android.content.Context, node: DocumentFile, result: MutableList<StatusMedia>, depth: Int, visited: IntArray) {
    if (depth > 8 || result.size > 1000 || visited[0] >= 80) return
    if (node.isDirectory && node.name.equals(".Statuses", ignoreCase = true)) {
        walkTree(context, node, result, 0)
        return
    }
    if (node.isDirectory) try {
        node.listFiles().filter { child ->
            if (!child.isDirectory) return@filter false
            val name = child.name.orEmpty()
            name.equals("Android", ignoreCase = true) ||
                name.equals("media", ignoreCase = true) ||
                name.equals("Media", ignoreCase = true) ||
                name.contains("whatsapp", ignoreCase = true) ||
                name.equals(".Statuses", ignoreCase = true)
        }.forEach { child ->
            if (visited[0] < 80) {
                visited[0]++
                findStatusFolders(context, child, result, depth + 1, visited)
            }
        }
    } catch (_: SecurityException) {}
}

private fun walkTree(context: android.content.Context, node: DocumentFile, result: MutableList<StatusMedia>, depth: Int) {
    if (depth > 6 || result.size > 1000) return
    try {
        node.listFiles().forEach { child ->
            if (child.isDirectory) walkTree(context, child, result, depth + 1)
            else {
                val mime = child.type.orEmpty()
                val kind = if (mime.startsWith("image/")) MediaKind.PHOTO else if (mime.startsWith("video/")) MediaKind.VIDEO else null
                if (kind != null) result += StatusMedia(child.uri, child.name ?: "status", kind, child.length(), "WhatsApp folder", child.lastModified())
            }
        }
    } catch (_: SecurityException) {}
}

private fun saveMedia(context: android.content.Context, items: List<StatusMedia>, done: (Int, Int, String?) -> Unit) {
    var saved = 0; var skipped = 0; var error: String? = null
    items.forEach { item ->
        try {
            val collection = if (item.kind == MediaKind.PHOTO) MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) else MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val dest = if (item.kind == MediaKind.PHOTO) "Pictures/StatusSaver" else "Movies/StatusSaver"
            val digest = digest(context.contentResolver.openInputStream(item.uri) ?: throw IllegalStateException("Source unavailable"))
            if (isDuplicate(context, collection, dest, item.size, digest)) { skipped++; return@forEach }
            val name = safeFileName(item.name)
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, context.contentResolver.getType(item.uri) ?: if (item.kind == MediaKind.PHOTO) "image/jpeg" else "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, dest)
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val outUri = context.contentResolver.insert(collection, values) ?: throw IllegalStateException("Could not create destination file")
            try {
                context.contentResolver.openOutputStream(outUri)?.use { out -> context.contentResolver.openInputStream(item.uri)?.use { input -> input.copyTo(out) } } ?: throw IllegalStateException("Could not copy file")
                if (Build.VERSION.SDK_INT >= 29) context.contentResolver.update(outUri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                saved++
            } catch (e: Exception) { context.contentResolver.delete(outUri, null, null); throw e }
        } catch (e: Exception) { error = e.message ?: "One or more files could not be saved" }
    }
    done(saved, skipped, error)
}

private fun isDuplicate(context: android.content.Context, collection: Uri, path: String, size: Long, hash: String): Boolean {
    val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.RELATIVE_PATH)
    context.contentResolver.query(collection, projection, "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.SIZE}=?", arrayOf(path + "/", size.toString()), null)?.use { c ->
        val idIx = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
        while (c.moveToNext()) {
            val uri = ContentUris.withAppendedId(collection, c.getLong(idIx))
            val existing = context.contentResolver.openInputStream(uri)?.use { digest(it) }
            if (existing == hash) return true
        }
    }
    return false
}

private fun digest(stream: InputStream): String = stream.use { input ->
    val md = MessageDigest.getInstance("SHA-256")
    val buffer = ByteArray(64 * 1024)
    while (true) { val n = input.read(buffer); if (n < 0) break; md.update(buffer, 0, n) }
    md.digest().joinToString("") { "%02x".format(it) }
}
private fun safeFileName(value: String): String = value.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._ -]"), "_").take(120).ifBlank { "status_media" }
private fun displayName(context: android.content.Context, uri: Uri): String = context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null } ?: uri.lastPathSegment ?: "status media"
private fun querySize(context: android.content.Context, uri: Uri): Long = context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L
private fun saveMessage(saved: Int, skipped: Int, error: String?): String = buildString { append("Saved $saved"); if (skipped > 0) append(" · $skipped duplicate${if (skipped == 1) "" else "s"} skipped"); if (error != null) append(" · Some files could not be saved") }
